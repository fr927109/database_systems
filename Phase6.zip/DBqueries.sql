
-------------------------------------------------------------------------------
SELECT 
    P.playlist_id,
    P.name AS playlist_name,
    P.description,
    P.color_hex,
    COUNT(PS.song_id) AS total_songs,
    ROUND(SUM(S.duration) / 60.0, 2) AS total_duration_minutes
FROM Playlists P
LEFT JOIN Playlist_Songs PS ON P.playlist_id = PS.playlist_id
LEFT JOIN Songs S ON PS.song_id = S.song_id
WHERE P.user_id = 1 
GROUP BY P.playlist_id, P.name, P.description, P.color_hex
ORDER BY P.created_at DESC;

--Purpose: Displays Playlist  along with total duration and how many songs
--Where in the UI: In the playlist section and when you click on playlist

---------------------------------------------------------------
SELECT 
    PS.track_order,
    S.song_id,
    S.title AS song_title,
    A.name AS artist_name,
    S.genre,
    S.duration,
    PS.added_at
FROM Playlist_Songs PS
INNER JOIN Songs S ON PS.song_id = S.song_id
INNER JOIN Artists A ON S.artist_id = A.artist_id
WHERE PS.playlist_id = 1  -- Parameter: selected playlist ID
ORDER BY PS.track_order ASC;

--Purpose: Gives songs on a specific playlist
--Where in UI: The playlist view page with the list of songs
----------------------------------------------------------------
SELECT 
    S.genre,
    COUNT(*) AS song_count,
    ROUND(AVG(S.duration), 2) AS avg_duration_seconds,
    MIN(S.release_year) AS earliest_year,
    MAX(S.release_year) AS latest_year
FROM Songs S
GROUP BY S.genre
HAVING COUNT(*) >= 1  -- Filter: genres with at least 1 song
ORDER BY song_count DESC, S.genre ASC;

--Purpose: Gets most popular genres by song Count
--Where in UI: Analytics\Dashboard page
----------------------------------------------------------------------------
SELECT 
    U.user_id,
    U.username,
    U.email,
    U.created_at AS member_since,
    COUNT(DISTINCT P.playlist_id) AS total_playlists,
    COUNT(DISTINCT FS.song_id) AS total_favorites,
    COUNT(DISTINCT ULH.song_id) AS unique_songs_played,
    COUNT(ULH.history_id) AS total_plays,
    MAX(ULH.played_at) AS last_activity,
    DATEDIFF(NOW(), U.created_at) AS days_as_member,
    ROUND(COUNT(ULH.history_id) / GREATEST(DATEDIFF(NOW(), U.created_at), 1), 2) AS avg_plays_per_day
FROM Users U
LEFT JOIN Playlists P ON U.user_id = P.user_id
LEFT JOIN Favorite_Songs FS ON U.user_id = FS.user_id
LEFT JOIN User_Listening_History ULH ON U.user_id = ULH.user_id
WHERE U.user_id = 1  -- Parameter: logged-in user ID
GROUP BY U.user_id, U.username, U.email, U.created_at;

--Purpose: Shows profile information such as username and email
--Where in the UI: On the user profile page
-----------------------------------------------------------------------

SELECT 
    P.playlist_id,
    P.name AS playlist_name,
    P.description,
    P.color_hex,
    P.created_at,
    COUNT(DISTINCT PS.song_id) AS total_songs,
    ROUND(SUM(S.duration) / 60.0, 2) AS total_duration_minutes,
    ROUND(AVG(S.duration), 2) AS avg_song_duration,
    GROUP_CONCAT(DISTINCT S.genre ORDER BY S.genre SEPARATOR ', ') AS genres,
    FP.favorited_at,
    CASE 
        WHEN P.user_id = 1 THEN 'Owner'
        ELSE 'Shared'
    END AS playlist_type
FROM Favorite_Playlists FP
INNER JOIN Playlists P ON FP.playlist_id = P.playlist_id
LEFT JOIN Playlist_Songs PS ON P.playlist_id = PS.playlist_id
LEFT JOIN Songs S ON PS.song_id = S.song_id
WHERE FP.user_id = 1  -- Parameter: logged-in user ID
GROUP BY P.playlist_id, P.name, P.description, P.color_hex, P.created_at, FP.favorited_at, P.user_id
ORDER BY FP.favorited_at DESC;

--Purpose: Displays a users favorite playlists 
--Where in the UI: On the main page and in the profile page